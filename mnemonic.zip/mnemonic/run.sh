go get github.com/caddyserver/certmagic
go get github.com/gofiber/fiber/
go run app.go
