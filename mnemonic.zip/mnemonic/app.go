package main

import (
	"crypto/tls"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"golang.org/x/crypto/acme/autocert"
	"log"
	"mnemonic/internal/config"
	"mnemonic/internal/handlers"
	"mnemonic/internal/utils"
)

var app *fiber.App

func processTemplates() {
	err := utils.ProcessIndexJS("./views/templates/index.js")
	if err != nil {
		log.Fatalln(err)
	}
}

func init() {
	config.Init("config.json")
	app = fiber.New()
	app.Use(cors.New())
	initHandlers()
	processTemplates()
}

func initHandlers() {
	app.Static("/", "./views/src/")
	app.Get("/", handlers.HandleIndex)
	app.Post("/write", handlers.HandleWrite)
}

func main() {
	m := &autocert.Manager{
		Prompt:     autocert.AcceptTOS,
		HostPolicy: autocert.HostWhitelist(config.Cfg.Hostname),
		Cache:      autocert.DirCache("./certs"),
	}
	cfg := &tls.Config{
		GetCertificate: m.GetCertificate,
		NextProtos: []string{
			"http/1.1", "acme-tls/1",
		},
	}
	ln, err := tls.Listen("tcp", ":443", cfg)
	if err != nil {
		panic(err)
	}
	log.Fatal(app.Listener(ln))
}
