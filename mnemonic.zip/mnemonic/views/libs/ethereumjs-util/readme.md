Build (will create a bundle and copy it to /tmp/ethereumjs-util.js):

    npm install
    npm run build
